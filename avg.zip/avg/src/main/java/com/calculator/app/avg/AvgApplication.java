package com.calculator.app.avg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvgApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvgApplication.class, args);
	}

}
